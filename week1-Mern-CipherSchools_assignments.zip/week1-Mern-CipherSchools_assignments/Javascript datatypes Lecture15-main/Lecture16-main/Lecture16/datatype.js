Strings 
console.log(typeof ("Hello"));
let word = 'raining'  
console.log(word.toUpperCase()); 

let let = "hi"  - WRONG 


console.log("Hello and good evening".length);
console.log("Hello".charAt(4));


boolean (true-1,false-0)
True value --> any value
False value --> 0, false,'',NaN, undefined
console.log(typeof true);
console.log(typeof false);
console.log(typeof isNaN('five'));

if(1){
console.log("Very True ! ")
} else{
console.log("Very Wrong ! ")
} 

if ("hello") {
console.log("very true");
} else {
console.log("very wrong");
}


console.log("hello".includes('e'));

Null Undefined
let score1;
let result1 = null;

console.log(typeof(score1));
console.log(typeof(result1));

if (result1) {
console.log("very true");
} else {
console.log("very wrong");
}
