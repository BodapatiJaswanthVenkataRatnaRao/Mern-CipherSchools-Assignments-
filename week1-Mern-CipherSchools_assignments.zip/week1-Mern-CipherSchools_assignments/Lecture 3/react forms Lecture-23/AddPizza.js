import React from 'react'

function AddPizza() {
  return (
    <div>
        <input type='text'>name</input>
        <input type='password'>Password</input>
        <button>Add card</button>
    </div>
  )
}

export default AddPizza